package com.yazty;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Yatzy {

    //pas besoin de mettre protected
    private int[] dice;


    public Yatzy(int d1, int d2, int d3, int d4, int d5) {

        dice = IntStream.of(d1, d2, d3, d4, d5).toArray();

    }

    //use short cercuiting
    public static int yatzy(int... dice) {
        final boolean isYatzy = Arrays.stream(dice)
                .allMatch(Integer.valueOf(dice[0])::equals);
        return isYatzy ? 50 : 0;

    }


    public static int chance(int d1, int d2, int d3, int d4, int d5) {
        return IntStream.of(d1, d2, d3, d4, d5)
                .sum();

    }


    public static int ones(int d1, int d2, int d3, int d4, int d5) {
        return getSumOfOccurences(1, d1, d2, d3, d4, d5);

    }

    public static int twos(int d1, int d2, int d3, int d4, int d5) {

        return getSumOfOccurences(2, d1, d2, d3, d4, d5);
    }

    public static int threes(int d1, int d2, int d3, int d4, int d5) {
        return getSumOfOccurences(3, d1, d2, d3, d4, d5);
    }


    public int fours() {
        return getSumOfOccurences(4, dice);

    }

    public int fives() {

        return getSumOfOccurences(5, dice);
    }

    public int sixes() {

        return getSumOfOccurences(6, dice);
    }

    public static int score_pair(int d1, int d2, int d3, int d4, int d5) {


        return 2 * IntStream.of(getNOfAKind(2, d1, d2, d3, d4, d5))
                .max()
                .orElse(0);
    }

    //return the sum of all dice that validate condition
    private static int getSumOfOccurences(int valueToCheck, int... dices) {
        return IntStream.of(dices)
                .filter(value -> value == valueToCheck)
                .sum();

    }

    //fill table with all duplicated values or not
    private static int[] getCounts(int d1, int d2, int d3, int d4, int d5) {
        int[] counts = new int[6];
        IntStream.of(d1, d2, d3, d4, d5)
                .forEach(d -> counts[d - 1]++);
        return counts;
    }

    // return table with number of kind
    private static int[] getNOfAKind(int n, int d1, int d2, int d3, int d4, int d5) {

        return IntStream.range(0, 6)
                .filter(i -> getCounts(d1, d2, d3, d4, d5)[i] >= n)
                .map(i -> i + 1)
                .toArray();

    }

    public static int two_pair(int d1, int d2, int d3, int d4, int d5) {
        return getNOfAKind(2, d1, d2, d3, d4, d5).length >= 2 ?
                IntStream.of(getNOfAKind(2, d1, d2, d3, d4, d5)).map(value -> 2 * value).sum() : 0;

    }


    public static int four_of_a_kind(int d1, int d2, int d3, int d4, int d5) {
        return getNOfAKind(4, d1, d2, d3, d4, d5).length > 0 ? 4 * getNOfAKind(4, d1, d2, d3, d4, d5)[0] : 0;
    }

    public static int three_of_a_kind(int d1, int d2, int d3, int d4, int d5) {
        return getNOfAKind(3, d1, d2, d3, d4, d5).length > 0 ? 3 * getNOfAKind(3, d1, d2, d3, d4, d5)[0] : 0;

    }

    public static int smallStraight(int d1, int d2, int d3, int d4, int d5) {
        return IntStream.range(0, 5)
                .filter(i -> getCounts(d1, d2, d3, d4, d5)[i] == 1)
                .toArray().length == 5 ? 15 : 0;

    }

    public static int largeStraight(int d1, int d2, int d3, int d4, int d5) {
        return IntStream.range(1, 6)
                .filter(i -> getCounts(d1, d2, d3, d4, d5)[i] == 1)
                .toArray().length == 5 ? 20 : 0;
    }

    public static int fullHouse(int d1, int d2, int d3, int d4, int d5) {
        int[] kindThree = getNOfAKind(3, d1, d2, d3, d4, d5);
        int[] pairs = getNOfAKind(2, d1, d2, d3, d4, d5);

        if (kindThree.length != 1 || pairs.length != 2) {
            return 0;
        }
        return 3 * kindThree[0] + 2 * (kindThree[0] == pairs[0] ? pairs[1] : pairs[0]);
    }
}
